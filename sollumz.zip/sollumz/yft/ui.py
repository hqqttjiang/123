import bpy
from bpy.types import (
    Object,
)
from ..sollumz_ui import SOLLUMZ_PT_OBJECT_PANEL, SOLLUMZ_PT_MAT_PANEL
from ..ydr.ui import SOLLUMZ_PT_BONE_PANEL
from ..ybn.ui import SOLLUMZ_PT_BOUND_PROPERTIES_PANEL
from ..sollumz_properties import (
    MaterialType,
    SollumType,
    BOUND_TYPES,
    SOLLUMZ_UI_NAMES,
    MIN_VEHICLE_LIGHT_ID,
    MAX_VEHICLE_LIGHT_ID,
)
from ..sollumz_helper import find_sollumz_parent
from ..sollumz_ui import FlagsPanel
from ..icons import icon
from .properties import (
    GroupProperties, FragmentProperties, VehicleWindowProperties, VehicleLightID,
    GroupFlagBit,
    VehiclePaintLayer,
)
from .operators import (
    SOLLUMZ_OT_CREATE_FRAGMENT, SOLLUMZ_OT_CREATE_BONES_AT_OBJECTS, SOLLUMZ_OT_SET_MASS, SOLLUMZ_OT_SET_LIGHT_ID,
    SOLLUMZ_OT_SELECT_LIGHT_ID, SOLLUMZ_OT_COPY_FRAG_BONE_PHYSICS,
    SOLLUMZ_OT_GENERATE_WHEEL_INSTANCES,
    SOLLUMZ_OT_vehicle_preview_generated_windows,
)


class SOLLUMZ_PT_FRAGMENT_TOOL_PANEL(bpy.types.Panel):
    bl_label = "Fragments"
    bl_idname = "SOLLUMZ_PT_FRAGMENT_TOOL_PANEL"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_options = {"DEFAULT_CLOSED"}
    bl_category = "Sollumz Tools"
    bl_order = 3

    def draw_header(self, context):
        self.layout.label(text="", icon="MOD_PHYSICS")

    def draw(self, context):
        pass


class FragmentToolChildPanel:
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_options = {"DEFAULT_CLOSED"}
    bl_parent_id = SOLLUMZ_PT_FRAGMENT_TOOL_PANEL.bl_idname
    bl_category = SOLLUMZ_PT_FRAGMENT_TOOL_PANEL.bl_category


class SOLLUMZ_PT_FRAGMENT_CREATE_PANEL(FragmentToolChildPanel, bpy.types.Panel):
    bl_label = "Create Fragment Objects"
    bl_idname = "SOLLUMZ_PT_FRAGMENT_CREATE_PANEL"
    bl_order = 1

    def draw_header(self, context):
        self.layout.label(text="", icon="ADD")

    def draw(self, context):
        layout = self.layout
        layout.operator(SOLLUMZ_OT_CREATE_FRAGMENT.bl_idname,
                        icon="MOD_PHYSICS")

        layout.separator()

        row = layout.row()
        row.operator(SOLLUMZ_OT_CREATE_BONES_AT_OBJECTS.bl_idname,
                     icon="BONE_DATA")
        row = layout.row()
        row.prop(context.scene, "create_bones_fragment")
        row.prop(context.scene, "create_bones_parent_to_selected")


class SOLLUMZ_PT_FRAGMENT_SET_MASS_PANEL(FragmentToolChildPanel, bpy.types.Panel):
    bl_label = "Set Mass"
    bl_idname = "SOLLUMZ_PT_FRAGMENT_SET_MASS_PANEL"
    bl_order = 2

    def draw_header(self, context):
        self.layout.label(text="", icon="WORLD")

    def draw(self, context):
        layout = self.layout
        row = layout.row(align=True)
        row.operator(SOLLUMZ_OT_SET_MASS.bl_idname, icon="WORLD")
        row.prop(context.scene, "set_mass_amount", text="")
        layout.operator("sollumz.calculate_mass", icon="SNAP_VOLUME")


class SOLLUMZ_PT_FRAGMENT_COPY_BONE_PHYSICS_PANEL(FragmentToolChildPanel, bpy.types.Panel):
    bl_label = "Copy Bone Physics"
    bl_idname = "SOLLUMZ_PT_FRAGMENT_COPY_BONE_PHYSICS_PANEL"
    bl_order = 4

    def draw_header(self, context):
        self.layout.label(text="", icon="BONE_DATA")

    def draw(self, context):
        layout = self.layout
        row = layout.row(align=True)
        row.operator(SOLLUMZ_OT_COPY_FRAG_BONE_PHYSICS.bl_idname, icon="BONE_DATA")


class SOLLUMZ_PT_VEHICLE_TOOLS_PANEL(FragmentToolChildPanel, bpy.types.Panel):
    bl_label = "Vehicle Tools"
    bl_idname = "SOLLUMZ_PT_VEHICLE_TOOLS_PANEL"
    bl_order = 3

    def draw_header(self, context):
        self.layout.label(text="", icon_value=icon("vehicle_tools"))

    def draw(self, context):
        layout = self.layout
        layout.use_property_decorate = False
        layout.use_property_split = True

        layout.operator(SOLLUMZ_OT_vehicle_preview_generated_windows.bl_idname, text="Preview Windows", icon="VIEWZOOM")
        layout.operator(SOLLUMZ_OT_GENERATE_WHEEL_INSTANCES.bl_idname,
                        text="Preview Wheel Instances", icon_value=icon("wheel"))

        layout.separator()

        layout.label(text="Light IDs", icon="OUTLINER_OB_LIGHT")
        row = layout.row(align=True)
        row.operator(SOLLUMZ_OT_SET_LIGHT_ID.bl_idname, icon="OUTLINER_OB_LIGHT")
        row.prop(context.scene, "set_vehicle_light_id", text="")

        if context.scene.set_vehicle_light_id == VehicleLightID.CUSTOM:
            layout.prop(context.scene, "set_custom_vehicle_light_id")
            layout.separator()

        row = layout.row(align=True)

        row.operator(SOLLUMZ_OT_SELECT_LIGHT_ID.bl_idname, icon="GROUP_VERTEX")
        row.prop(context.scene, "select_vehicle_light_id", text="")

        if context.scene.select_vehicle_light_id == VehicleLightID.CUSTOM:
            layout.prop(context.scene, "select_custom_vehicle_light_id")
            layout.separator()

        face_mode = context.scene.tool_settings.mesh_select_mode[2]

        if context.mode == "EDIT_MESH" and face_mode:
            light_id = context.scene.selected_vehicle_light_id
            if light_id == -1:
                light_id = "N/A"
            elif 0 <= light_id <= 17:
                light_id_enum = VehicleLightID(str(light_id))
                light_id = f"{SOLLUMZ_UI_NAMES[light_id_enum]} ({light_id})"

            layout.label(text=f"Selection Light ID: {light_id}")
        else:
            layout.label(text="Must be in Edit Mode > Face Selection.", icon="ERROR")


class SOLLUMZ_PT_FRAGMENT_PANEL(bpy.types.Panel):
    bl_label = "Fragment"
    bl_idname = "SOLLUMZ_PT_FRAGMENT_PANEL"
    bl_space_type = "PROPERTIES"
    bl_region_type = "WINDOW"
    bl_options = {"HIDE_HEADER"}
    bl_parent_id = SOLLUMZ_PT_OBJECT_PANEL.bl_idname

    @classmethod
    def poll(cls, context):
        return context.active_object is not None and context.active_object.sollum_type == SollumType.FRAGMENT

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False

        obj = context.active_object

        for prop in FragmentProperties.__annotations__:
            if prop == "lod_properties" or prop == "cloth" or prop == "vehicle_render_preview":
                continue
            # skip flags because these don't look like they should be user-editable
            if prop == "flags":
                continue

            layout.prop(obj.fragment_properties, prop)


class SOLLUMZ_PT_PHYS_LODS_PANEL(bpy.types.Panel):
    bl_label = "Physics LOD Properties"
    bl_idname = "SOLLUMZ_PT_PHYS_LODS_PANEL"
    bl_space_type = "PROPERTIES"
    bl_region_type = "WINDOW"
    bl_context = "object"
    bl_options = {"DEFAULT_CLOSED"}
    bl_parent_id = SOLLUMZ_PT_FRAGMENT_PANEL.bl_idname
    bl_order = 1

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False

        obj = context.view_layer.objects.active
        lod_props = obj.fragment_properties.lod_properties

        for prop in lod_props.__annotations__:
            if prop == "archetype_properties":
                continue
            layout.prop(lod_props, prop)


class SOLLUMZ_PT_FRAG_ARCHETYPE_PANEL(bpy.types.Panel):
    bl_label = "Archetype Properties"
    bl_idname = "SOLLUMZ_PT_FRAG_ARCHETYPE_PANEL"
    bl_space_type = "PROPERTIES"
    bl_region_type = "WINDOW"
    bl_context = "object"
    bl_options = {"DEFAULT_CLOSED"}
    bl_parent_id = SOLLUMZ_PT_FRAGMENT_PANEL.bl_idname
    bl_order = 2

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False

        obj = context.view_layer.objects.active
        arch_props = obj.fragment_properties.lod_properties.archetype_properties

        for prop in arch_props.__annotations__:
            layout.prop(arch_props, prop)


class ClothPanel:
    bl_space_type = "PROPERTIES"
    bl_region_type = "WINDOW"
    bl_context = "object"
    bl_options = {"DEFAULT_CLOSED"}

    @property
    def has_cloth(self) -> bool:
        from ..ydr.cloth_env import cloth_env_find_mesh_objects
        obj = bpy.context.view_layer.objects.active
        cloth_objs = cloth_env_find_mesh_objects(obj, silent=True)
        return bool(cloth_objs)


class SOLLUMZ_PT_FRAG_CLOTH_PANEL(ClothPanel, bpy.types.Panel):
    bl_label = "Cloth"
    bl_idname = "SOLLUMZ_PT_FRAG_CLOTH_PANEL"
    bl_parent_id = SOLLUMZ_PT_FRAGMENT_PANEL.bl_idname
    bl_order = 3

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False

        obj = context.view_layer.objects.active
        cloth_props = obj.fragment_properties.cloth

        has_cloth = self.has_cloth
        if not has_cloth:
            layout.label(text="No cloth in the active fragment.", icon="ERROR")
        col = layout.column()
        col.active = has_cloth
        col.prop(cloth_props, "weight")
        col.prop(cloth_props, "world_bounds")


class SOLLUMZ_PT_FRAG_CLOTH_TUNING_PANEL(ClothPanel, bpy.types.Panel):
    bl_label = "Tuning"
    bl_idname = "SOLLUMZ_PT_FRAG_CLOTH_TUNING_PANEL"
    bl_parent_id = SOLLUMZ_PT_FRAG_CLOTH_PANEL.bl_idname
    bl_order = 1

    def draw_header(self, context):
        layout = self.layout

        obj = context.view_layer.objects.active
        cloth_props = obj.fragment_properties.cloth

        layout.active = self.has_cloth
        layout.prop(cloth_props, "enable_tuning", text="")

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False

        obj = context.view_layer.objects.active
        cloth_props = obj.fragment_properties.cloth

        layout.active = self.has_cloth and cloth_props.enable_tuning
        layout.prop(cloth_props, "extra_force")
        layout.prop(cloth_props, "weight_override")
        row = layout.row()
        row.active = cloth_props.tuning_flags.use_distance_threshold or cloth_props.tuning_flags.force_vertex_resistance
        row.prop(
            cloth_props,
            "distance_threshold",
            text="Vertex Resistance" if cloth_props.tuning_flags.force_vertex_resistance else "Distance Threshold"
        )


class SOLLUMZ_PT_FRAG_CLOTH_TUNING_WIND_FEEDBACK_PANEL(ClothPanel, bpy.types.Panel):
    bl_label = "Wind Feedback"
    bl_idname = "SOLLUMZ_PT_FRAG_CLOTH_TUNING_WIND_FEEDBACK_PANEL"
    bl_parent_id = SOLLUMZ_PT_FRAG_CLOTH_TUNING_PANEL.bl_idname
    bl_order = 1

    def draw_header(self, context):
        layout = self.layout

        obj = context.view_layer.objects.active
        cloth_props = obj.fragment_properties.cloth

        layout.active = self.has_cloth and cloth_props.enable_tuning
        layout.prop(cloth_props.tuning_flags, "wind_feedback", text="")

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False

        obj = context.view_layer.objects.active
        cloth_props = obj.fragment_properties.cloth

        layout.active = self.has_cloth and cloth_props.enable_tuning and cloth_props.tuning_flags.wind_feedback
        layout.prop(cloth_props, "rotation_rate")
        layout.prop(cloth_props, "angle_threshold")
        layout.prop(cloth_props, "pin_vert")
        layout.prop(cloth_props, "non_pin_vert0")
        layout.prop(cloth_props, "non_pin_vert1")


class SOLLUMZ_PT_FRAG_CLOTH_TUNING_FLAGS_PANEL(FlagsPanel, ClothPanel, bpy.types.Panel):
    bl_label = "Flags"
    bl_idname = "SOLLUMZ_PT_FRAG_CLOTH_TUNING_FLAGS_PANEL"
    bl_parent_id = SOLLUMZ_PT_FRAG_CLOTH_TUNING_PANEL.bl_idname
    bl_order = 2

    def get_flags(self, context):
        obj = context.view_layer.objects.active
        cloth_props = obj.fragment_properties.cloth
        return cloth_props.tuning_flags

    def draw(self, context):
        obj = context.view_layer.objects.active
        cloth_props = obj.fragment_properties.cloth
        self.layout.active = self.has_cloth and cloth_props.enable_tuning
        super().draw(context)


class VehicleRenderPreviewPanelImpl:
    bl_label = "Vehicle Render Preview"
    bl_space_type = "PROPERTIES"
    bl_region_type = "WINDOW"
    bl_context = "object"
    bl_options = {"DEFAULT_CLOSED"}

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False

        # NOTE: obj may be a fragment or drawable, both can use vehicle shaders.
        # It is okay to access fragment_properties because it is registered on the blender Object type,
        # so it is always available even on objects that are not actually fragments.
        obj = context.view_layer.objects.active

        has_vehicle_shaders = self.has_vehicle_shaders(obj)
        if not has_vehicle_shaders:
            what = "fragment" if obj.sollum_type == SollumType.FRAGMENT else "drawable"
            layout.label(text=f"No vehicle shaders in the active {what}.", icon="ERROR")
        col = layout.column()
        col.active = has_vehicle_shaders

        if obj.parent and obj.parent.sollum_type == SollumType.FRAGMENT:
            # If we are the drawable of a fragment, use the vehicle_render_preview of the fragment, so selecting either
            # the fragment or its drawable show the same stored preview colors/values
            obj = obj.parent
        render_preview = obj.fragment_properties.vehicle_render_preview
        col.prop(render_preview, "dirt_level")
        col.prop(render_preview, "dirt_wetness")
        col.prop(render_preview, "dirt_color")

        for paint_layer_id in range(1, 7+1):
            if paint_layer_id == VehiclePaintLayer.DEFAULT:
                continue
            col.prop(render_preview, f"body_color_{paint_layer_id}")

        col.label(text="Lights Emissive")
        grid = col.grid_flow(columns=3)
        for light_id in range(MIN_VEHICLE_LIGHT_ID, MAX_VEHICLE_LIGHT_ID+1):
            grid.prop(render_preview, f"light_id_{light_id}")

    def has_vehicle_shaders(self, obj: Object):
        for obj in obj.children_recursive:
            if obj.sollum_type != SollumType.DRAWABLE_MODEL or obj.type != "MESH":
                continue

            mesh = obj.data
            if any(m.shader_properties.filename.startswith("vehicle_") for m in mesh.materials):
                return True

        return False


class SOLLUMZ_PT_FRAGMENT_VEHICLE_RENDER_PREVIEW_PANEL(VehicleRenderPreviewPanelImpl, bpy.types.Panel):
    bl_idname = "SOLLUMZ_PT_FRAGMENT_VEHICLE_RENDER_PREVIEW_PANEL"
    bl_parent_id = SOLLUMZ_PT_FRAGMENT_PANEL.bl_idname
    bl_order = 3


# Wheel drawables also use the vehicle shaders, not just fragments, so make another panel for drawables
class SOLLUMZ_PT_DRAWABLE_VEHICLE_RENDER_PREVIEW_PANEL(VehicleRenderPreviewPanelImpl, bpy.types.Panel):
    bl_idname = "SOLLUMZ_PT_DRAWABLE_VEHICLE_RENDER_PREVIEW_PANEL"
    bl_parent_id = "SOLLUMZ_PT_DRAWABLE_PANEL"
    bl_order = 3


class SOLLUMZ_PT_BONE_PHYSICS_PANEL(bpy.types.Panel):
    bl_label = "Fragment Physics"
    bl_idname = "SOLLUMZ_PT_BONE_PHYSICS_PANEL"
    bl_space_type = "PROPERTIES"
    bl_region_type = "WINDOW"
    bl_context = "bone"
    bl_options = {"DEFAULT_CLOSED"}
    bl_parent_id = SOLLUMZ_PT_BONE_PANEL.bl_idname

    @classmethod
    def poll(cls, context):
        return context.active_bone is not None and context.active_object.sollum_type == SollumType.FRAGMENT

    def draw_header(self, context):
        bone = context.active_bone
        self.layout.prop(bone, "sollumz_use_physics", text="")

    def draw(self, context):
        bone = context.active_bone
        props = bone.group_properties

        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        layout.active = bone.sollumz_use_physics

        col = layout.column(heading="Flags")
        col.prop(props, "flags", index=GroupFlagBit.DISAPPEAR_WHEN_DEAD, text="Disappear When Dead")
        col.prop(props, "flags", index=GroupFlagBit.DAMAGE_WHEN_BROKEN, text="Damage When Broken")
        col.prop(props, "flags", index=GroupFlagBit.DOESNT_AFFECT_VEHICLES, text="Doesn't Affect Vehicles")
        col.prop(props, "flags", index=GroupFlagBit.DOESNT_PUSH_VEHICLES_DOWN, text="Doesn't Push Vehicles Down")
        col.prop(props, "flags", index=GroupFlagBit.HAS_CLOTH, text="Has Cloth")

        col = layout.column(heading="Breakable Glass")
        row = col.row(align=True)
        row.prop(props, "flags", index=GroupFlagBit.USE_GLASS_WINDOW, text="")
        sub = row.row(align=True)
        sub.active = props.flags[GroupFlagBit.USE_GLASS_WINDOW]
        sub.prop(props, "glass_type", text="")

        col = layout.column()
        for prop in GroupProperties.__annotations__:
            if prop in {"flags", "glass_type"}:
                continue

            col.prop(props, prop)


class SOLLUMZ_PT_PHYSICS_CHILD_PANEL(bpy.types.Panel):
    bl_label = "Physics"
    bl_idname = "SOLLUMZ_PT_PHYSICS_CHILD_PANEL"
    bl_space_type = "PROPERTIES"
    bl_region_type = "WINDOW"
    bl_context = "object"
    bl_options = {"DEFAULT_CLOSED"}
    bl_parent_id = SOLLUMZ_PT_BOUND_PROPERTIES_PANEL.bl_idname

    bl_order = 2

    @classmethod
    def poll(cls, context):
        aobj = context.active_object
        return aobj is not None and aobj.sollum_type != SollumType.BOUND_COMPOSITE and aobj.sollum_type in BOUND_TYPES

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False

        aobj = context.active_object

        child_props = aobj.child_properties

        layout.prop(child_props, "mass")


class SOLLUMZ_PT_VEH_WINDOW_PANEL(bpy.types.Panel):
    bl_label = "Manual Shattermap"
    bl_idname = "SOLLUMZ_PT_VEHICLE_WINDOW_PANEL"
    bl_space_type = "PROPERTIES"
    bl_region_type = "WINDOW"
    bl_options = {"DEFAULT_CLOSED"}
    bl_parent_id = SOLLUMZ_PT_PHYSICS_CHILD_PANEL.bl_idname

    @classmethod
    def poll(cls, context):
        aobj = context.active_object
        return aobj and aobj.sollum_type == SollumType.BOUND_GEOMETRY

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False

        obj = context.active_object
        child_props = obj.child_properties

        layout.prop(child_props, "is_veh_window")

        if not child_props.is_veh_window:
            return

        layout.separator()

        layout.prop(child_props, "window_mat")

        for prop in VehicleWindowProperties.__annotations__:
            self.layout.prop(obj.vehicle_window_properties, prop)


class SOLLUMZ_PT_FRAGMENT_GEOMETRY_PANEL(bpy.types.Panel):
    bl_label = "Physics"
    bl_idname = "SOLLUMZ_PT_FRAGMENT_GEOMETRY_PANEL"
    bl_space_type = "PROPERTIES"
    bl_region_type = "WINDOW"
    bl_context = "object"
    bl_options = {"HIDE_HEADER"}
    bl_parent_id = SOLLUMZ_PT_OBJECT_PANEL.bl_idname

    @classmethod
    def poll(cls, context):
        aobj = context.active_object
        if aobj is None or aobj.sollum_type != SollumType.DRAWABLE_MODEL:
            return False

        return find_sollumz_parent(aobj, parent_type=SollumType.FRAGMENT) is not None

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False

        layout.prop(context.active_object,
                    "sollumz_is_physics_child_mesh", text="Is Wheel Mesh")


class SOLLUMZ_PT_FRAGMENT_MAT_PANEL(bpy.types.Panel):
    # "Fragment" is not a really good name because drawables like wheels can also use vehicle shaders with paint
    # layers, but keep it for now because it is probably mentioned in tutorials
    bl_label = "Fragment (Vehicle Paint)"
    bl_idname = "SOLLUMZ_PT_FRAGMENT_MAT_PANEL"
    bl_space_type = "PROPERTIES"
    bl_region_type = "WINDOW"
    bl_context = "material"
    bl_options = {"DEFAULT_CLOSED"}
    bl_parent_id = SOLLUMZ_PT_MAT_PANEL.bl_idname
    bl_order = 4

    @classmethod
    def poll(cls, context):
        aobj = context.active_object
        if aobj is None or aobj.sollum_type != SollumType.DRAWABLE_MODEL:
            return False

        mat = aobj.active_material
        return mat and mat.sollum_type == MaterialType.SHADER and mat.shader_properties.filename.startswith("vehicle_")

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False

        mat = context.active_object.active_material

        has_mat_diffuse_color = "matDiffuseColor" in mat.node_tree.nodes
        row = layout.row()
        row.enabled = has_mat_diffuse_color
        row.prop(mat, "sz_paint_layer")
        if not has_mat_diffuse_color:
            layout.label(text="Not a vehicle paint shader. Shader must have a matDiffuseColor parameter.", icon="ERROR")
